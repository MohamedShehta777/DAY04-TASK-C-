﻿// DAY04 TASK
//part01: 

//>> problem01 :  
using System;
using System.Diagnostics.Metrics;

class Program
{
    static void Main()
    {
        int[] array1 = new int[5];

        int[] array2 = { 1, 2, 3, 4, 5 };

        int[] array3 = new[] { 6, 7, 8, 9, 10 };

        Console.WriteLine("Array 1 (initialized with new int[size]):");
        for (int i = 0; i < array1.Length; i++)
        {
            array1[i] = i + 1;
            Console.WriteLine($"Element {i}: {array1[i]}");
        }

        Console.WriteLine("\nArray 2 (initialized with initializer list):");
        for (int i = 0; i < array2.Length; i++)
        {
            Console.WriteLine($"Element {i}: {array2[i]}");
        }

        Console.WriteLine("\nArray 3 (initialized with array syntax sugar):");
        for (int i = 0; i < array3.Length; i++)
        {
            Console.WriteLine($"Element {i}: {array3[i]}");
        }

        try
        {
            Console.WriteLine("\nAttempting to access an out-of-bounds index:");
            Console.WriteLine(array1[10]); 
        }
        catch (IndexOutOfRangeException e)
        {
            Console.WriteLine($"Exception caught: {e.Message}");
        }
    }
}
//question: 
//For value types   int: 0  -  float: 0.0   -  bool: false   -    char: \0(null character)
//For reference types null
//-----------------------------------------------------------------//

//>> problem02: 
using System;

class Program
{
    static void Main()
    {
       
        int[] arr1 = { 1, 2, 3, 4, 5 };
        int[] arr2;

        Console.WriteLine("Original Array (arr1):");
        PrintArray(arr1);

        arr2 = arr1; 
        Console.WriteLine("\nShallow Copy:");
        Console.WriteLine("Modifying arr1...");
        arr1[0] = 100; 
        Console.WriteLine("arr1:");
        PrintArray(arr1);
        Console.WriteLine("arr2 (after modifying arr1):");
        PrintArray(arr2);

        int[] arr3 = (int[])arr1.Clone(); 
        Console.WriteLine("\nDeep Copy using Clone:");
        Console.WriteLine("Modifying arr3...");
        arr3[0] = 200; 
        Console.WriteLine("arr1:");
        PrintArray(arr1);
        Console.WriteLine("arr3 (after modifying arr3):");
        PrintArray(arr3);

        int[] arr4 = new int[arr1.Length];
        Array.Copy(arr1, arr4, arr1.Length); 
        Console.WriteLine("\nDeep Copy using Array.Copy:");
        Console.WriteLine("Modifying arr4...");
        arr4[0] = 300; 
        Console.WriteLine("arr1:");
        PrintArray(arr1);
        Console.WriteLine("arr4 (after modifying arr4):");
        PrintArray(arr4);
    }

    static void PrintArray(int[] arr)
    {
        foreach (int item in arr)
        {
            Console.Write(item + " ");
        }
        Console.WriteLine();
    }
}
// question :
//The main difference is that Array.Clone() creates a new array, while Array.Copy() requires an existing target array.
//---------------------------------------------------------------------------------------//

//>> problem03: 
using System;

class Program
{
    static void Main()
    {
        int[,] grades = new int[3, 3];

        Console.WriteLine("Enter the grades for 3 students in 3 subjects:");

        for (int i = 0; i < 3; i++) 
        {
            Console.WriteLine($"Enter grades for Student {i + 1}:");
            for (int j = 0; j < 3; j++) 
            {
                Console.Write($"Subject {j + 1}: ");
                grades[i, j] = int.Parse(Console.ReadLine());
            }
        }

        Console.WriteLine("\nGrades for each student:");
        for (int i = 0; i < 3; i++)
        {
            Console.WriteLine($"Student {i + 1}:");
            for (int j = 0; j < 3; j++)
            {
                Console.Write(grades[i, j] + " ");
            }
            Console.WriteLine();
        }
    }
}

// Question: 
//Length: Gives the total number of elements in the array.
//GetLength(dimension): Gives the size of a specific dimension of the array.
//------------------------------------------------------------------------------------//
//>> problem04: 
using System;

class Program
{
    static void Main()
    {
        int[] numbers = { 5, 3, 8, 1, 9, 2, 7 };

        Console.WriteLine("Original Array:");
        PrintArray(numbers);

        Array.Sort(numbers);
        Console.WriteLine("\nArray after Sort:");
        PrintArray(numbers);

        Array.Reverse(numbers);
        Console.WriteLine("\nArray after Reverse:");
        PrintArray(numbers);

        int index = Array.IndexOf(numbers, 8);
        Console.WriteLine($"\nIndex of element 8: {index}");

        int[] copyArray = new int[3];
        Array.Copy(numbers, 0, copyArray, 0, 3);
        Console.WriteLine("\nArray after Copy (first 3 elements):");
        PrintArray(copyArray);

        Array.Clear(numbers, 0, 2);
        Console.WriteLine("\nArray after Clear (first 2 elements cleared):");
        PrintArray(numbers);
    }

    static void PrintArray(int[] arr)
    {
        foreach (var item in arr)
        {
            Console.Write(item + " ");
        }
        Console.WriteLine();
    }
}
//qusetion:: 
//Array.Copy() is more general and flexible, while Array.ConstrainedCopy()
//provides additional type safety checks during the copy process.
//---------------------------------------------------------------///

// problem05:

using System;

class Program
{
    static void Main()
    {
        int[] numbers = { 1, 2, 3, 4, 5 };

        Console.WriteLine("Using for loop:");
        for (int i = 0; i < numbers.Length; i++)
        {
            Console.Write(numbers[i] + " ");
        }
        Console.WriteLine();

        Console.WriteLine("Using foreach loop:");
        foreach (int number in numbers)
        {
            Console.Write(number + " ");
        }
        Console.WriteLine();

        Console.WriteLine("Using while loop (reverse order):");
        int j = numbers.Length - 1;
        while (j >= 0)
        {
            Console.Write(numbers[j] + " ");
            j--;
        }
        Console.WriteLine();
    }
}
//question: 
//foreach is preferred for read-only operations because it offers 
//simpler, cleaner, and less error-prone syntax compared to other loop constructs like for and while
///-------------------------------------------------------------------------------///

//>> problem06: 
using System;

class Program
{
    static void Main()
    {
        int number;

        
        do
        {
            Console.Write("Please enter a positive odd number: ");
            string input = Console.ReadLine();

            
            if (int.TryParse(input, out number))
            {
                
                if (number > 0 && number % 2 != 0)
                {
                    Console.WriteLine($"You entered a valid positive odd number: {number}");
                    break; 
                }
                else
                {
                    Console.WriteLine("The number must be positive and odd. Please try again.");
                }
            }
            else
            {
                Console.WriteLine("Invalid input. Please enter a valid number.");
            }
        } while (true); 
}
    //question: 
    // input validation is essential to ensure the program operates as intended, prevents errors, 
    //enhances the user experience, and ensures the correctness and security of the data being processed.
    //--------------------------------------------------------------------------//

    //>> problem 07: 
    using System;

class Program
{
    static void Main()
    {
        int[,] matrix =
        {
            { 1, 2, 3 },
            { 4, 5, 6 },
            { 7, 8, 9 }
        };

        Console.WriteLine("Matrix:");
        for (int i = 0; i < matrix.GetLength(0); i++) 
        {
            for (int j = 0; j < matrix.GetLength(1); j++) 
            {
                Console.Write($"{matrix[i, j],4} "); 
            }
            Console.WriteLine(); 
        }
    }
}
// question: 
//New Line after Each Row:
//After printing each row, make sure to move to the next line using Console.WriteLine() to maintain the matrix format.
//--------------------------------------------------------------------------------------//

//>> problem08: 
using System;

class Program
{
    static void Main()
    {
        Console.Write("Enter a month number (1-12): ");
        int monthNumber = int.Parse(Console.ReadLine());

        string monthNameIfElse = "";
        if (monthNumber == 1) monthNameIfElse = "January";
        else if (monthNumber == 2) monthNameIfElse = "February";
        else if (monthNumber == 3) monthNameIfElse = "March";
        else if (monthNumber == 4) monthNameIfElse = "April";
        else if (monthNumber == 5) monthNameIfElse = "May";
        else if (monthNumber == 6) monthNameIfElse = "June";
        else if (monthNumber == 7) monthNameIfElse = "July";
        else if (monthNumber == 8) monthNameIfElse = "August";
        else if (monthNumber == 9) monthNameIfElse = "September";
        else if (monthNumber == 10) monthNameIfElse = "October";
        else if (monthNumber == 11) monthNameIfElse = "November";
        else if (monthNumber == 12) monthNameIfElse = "December";
        else monthNameIfElse = "Invalid month number";

        Console.WriteLine("Using if-else: " + monthNameIfElse);

        string monthNameSwitch;
        switch (monthNumber)
        {
            case 1:
                monthNameSwitch = "January";
                break;
            case 2:
                monthNameSwitch = "February";
                break;
            case 3:
                monthNameSwitch = "March";
                break;
            case 4:
                monthNameSwitch = "April";
                break;
            case 5:
                monthNameSwitch = "May";
                break;
            case 6:
                monthNameSwitch = "June";
                break;
            case 7:
                monthNameSwitch = "July";
                break;
            case 8:
                monthNameSwitch = "August";
                break;
            case 9:
                monthNameSwitch = "September";
                break;
            case 10:
                monthNameSwitch = "October";
                break;
            case 11:
                monthNameSwitch = "November";
                break;
            case 12:
                monthNameSwitch = "December";
                break;
            default:
                monthNameSwitch = "Invalid month number";
                break;
        }

        Console.WriteLine("Using switch: " + monthNameSwitch);
    }
}
//question: 
//use switch when you have many possible values to compare against a single variable, 
//and use if-else when conditions are more complex or involve different variables. 
//----------------------------------------------------------------------//

//>> problem09: 
using System;

class Program
{
    static void Main()
    {
        int[] numbers = { 10, 3, 7, 1, 9, 5, 3, 8 };

        Console.WriteLine("Original array:");
        PrintArray(numbers);

        Array.Sort(numbers);
        Console.WriteLine("\nSorted array:");
        PrintArray(numbers);

        int searchValue = 3;
        int indexOf = Array.IndexOf(numbers, searchValue);
        Console.WriteLine($"\nIndex of value {searchValue}: {indexOf}");

        int lastIndexOf = Array.LastIndexOf(numbers, searchValue);
        Console.WriteLine($"Last index of value {searchValue}: {lastIndexOf}");
    }

    static void PrintArray(int[] array)
    {
        foreach (var num in array)
        {
            Console.Write(num + " ");
        }
        Console.WriteLine();
    }
}
//question: 
//The time complexity of Array.Sort() is typically O(n log n) for average cases,
//but it can degrade to O(n^2) in the worst case  if QuickSort is used with poorly balanced pivots.
//----------------------------------------------------------------------//

//>> problem 10: 
using System;

class Program
{
    static void Main()
    {
        // Create an array of integers
        int[] numbers = { 10, 20, 30, 40, 50 };

        // 1. Calculate the sum using a for loop
        int sumForLoop = 0;
        for (int i = 0; i < numbers.Length; i++)
        {
            sumForLoop += numbers[i];
        }
        Console.WriteLine("Sum using for loop: " + sumForLoop);

        // 2. Calculate the sum using a foreach loop
        int sumForeachLoop = 0;
        foreach (int num in numbers)
        {
            sumForeachLoop += num;
        }
        Console.WriteLine("Sum using foreach loop: " + sumForeachLoop);
    }
}
// question :
//the difference in efficiency is very small and usually won’t matter for most typical scenarios. If readability is a priority,
//use foreach; if performance is critical (with very large datasets or inside tight loops), then for might be the better choice.
//---------------------------------------------------------------------------------//

//>> part02 
//(2)
using System;

class Program
{
    enum Day
    {
        Sunday = 1,
        Monday = 2,
        Tuesday = 3,
        Wednesday = 4,
        Thursday = 5,
        Friday = 6,
        Saturday = 7
    }

    static void Main()
    {
        Console.Write("Enter a number (1-7) to get the corresponding day of the week: ");
        int dayNumber = int.Parse(Console.ReadLine());

        if (dayNumber < 1 || dayNumber > 7)
        {
            Console.WriteLine("Invalid input. Please enter a number between 1 and 7.");
            return;
        }

        Day day = (Day)Enum.Parse(typeof(Day), dayNumber.ToString());

        Console.WriteLine($"The corresponding day is: {day}");
    }
}







